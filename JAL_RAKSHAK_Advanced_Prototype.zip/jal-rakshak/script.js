"use strict";

const $ = id => document.getElementById(id);
const STORAGE_KEYS = { url: "jr_supabase_url", key: "jr_supabase_key" };

const stations = {
  river: { name: "River Watch", description: "Illustrative river monitoring profile", levelOffset: 0, rainOffset: 0, flowOffset: 0, turbidityOffset: 0 },
  reservoir: { name: "Reservoir Guard", description: "Illustrative reservoir monitoring profile", levelOffset: -10, rainOffset: -3, flowOffset: -0.5, turbidityOffset: -2 },
  village: { name: "Village Water Tank", description: "Illustrative village tank monitoring profile", levelOffset: -18, rainOffset: -5, flowOffset: -0.8, turbidityOffset: 8 }
};
const scenarios = {
  normal: { level: 42, rain: 8, flow: 1.8, turbidity: 12 },
  warning: { level: 68, rain: 28, flow: 3.4, turbidity: 24 },
  danger: { level: 91, rain: 62, flow: 5.7, turbidity: 48 },
  quality: { level: 45, rain: 12, flow: 2.1, turbidity: 95 }
};

const state = {
  readings: Object.fromEntries(Object.keys(stations).map(id => [id, []])),
  history: Object.fromEntries(Object.keys(stations).map(id => [id, []])),
  supabase: null,
  cloudReady: false,
  saving: false,
  lastCloudSaveAt: 0
};

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function getTime() { return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }); }
function updateClock() { $("clock").textContent = new Date().toLocaleTimeString(); }
function stationId() { return $("station").value; }

function generateReading() {
  const id = stationId();
  const station = stations[id] || stations.river;
  const scenarioId = $("scenario").value;
  const base = scenarios[scenarioId] || scenarios.normal;
  const applyOffsets = scenarioId === "normal" || scenarioId === "quality";
  const off = applyOffsets ? 1 : 0;
  return {
    station_id: id,
    station_name: station.name,
    source: "simulated",
    recorded_at: new Date().toISOString(),
    time: getTime(),
    level: Math.round(clamp(base.level + station.levelOffset * off + (Math.random() - .5) * 6, 0, 100)),
    rainfall: Math.round(clamp(base.rain + station.rainOffset * off + (Math.random() - .5) * 4, 0, 100)),
    flow_rate: Number(clamp(base.flow + station.flowOffset * off + (Math.random() - .5) * .4, 0, 10).toFixed(1)),
    turbidity: Math.round(clamp(base.turbidity + station.turbidityOffset * off + (Math.random() - .5) * 6, 0, 100))
  };
}

function assessRisk(r) {
  let score = Math.round(r.level * .55 + Math.min(r.rainfall, 100) * .20 + Math.min(r.flow_rate * 10, 100) * .15 + Math.min(r.turbidity, 100) * .10);
  score = clamp(score, 0, 100);
  let status = "normal";
  let explanation = "Simulated readings are below the configured demo warning thresholds.";
  if (r.level >= 80) {
    status = "danger";
    score = Math.max(score, 80);
    explanation = "Critical simulated water level. A real deployment would require validated thresholds and operational procedures.";
  } else if (r.level >= 60 || score >= 60 || r.turbidity >= 50) {
    status = "warning";
    if (r.level >= 60) score = Math.max(score, 60);
    explanation = r.turbidity >= 50
      ? "Simulated turbidity is high. This does not establish whether water is safe to drink."
      : "A simulated water-level or combined-risk threshold was crossed.";
  }
  return { score, status, explanation };
}

function setMeter(id, value, max) { $(id).style.width = clamp(value / max * 100, 0, 100) + "%"; }
function updateMeters(r) {
  $("waterLevel").textContent = r.level;
  $("rainfall").textContent = r.rainfall;
  $("flowRate").textContent = r.flow_rate.toFixed(1);
  $("turbidity").textContent = r.turbidity;
  setMeter("waterBar", r.level, 100);
  setMeter("rainBar", r.rainfall, 100);
  setMeter("flowBar", r.flow_rate, 10);
  setMeter("turbidityBar", r.turbidity, 100);
  $("waterNote").textContent = r.level >= 80 ? "Critical demo threshold" : r.level >= 60 ? "Warning demo threshold crossed" : "Below configured demo warning threshold";
}

function updateRisk(a) {
  $("riskScore").textContent = a.score;
  $("riskStatus").textContent = a.status.toUpperCase() + " RISK";
  $("riskStatus").className = "status-pill " + a.status;
  $("riskExplanation").textContent = a.explanation;
  $("riskCircle").style.borderColor = ({ normal: "#245f55", warning: "#9c712b", danger: "#a13e52" })[a.status];
}

function drawChart() {
  const data = state.readings[stationId()] || [];
  const canvas = $("levelChart");
  const rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(rect.width * dpr);
  canvas.height = Math.round(rect.height * dpr);
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);
  const w = rect.width, h = rect.height, left = 36, right = 12, top = 15, bottom = 27;
  const cw = w - left - right, ch = h - top - bottom;
  ctx.clearRect(0, 0, w, h);
  ctx.font = "11px Segoe UI, Arial";
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  for (let v = 0; v <= 100; v += 25) {
    const y = top + ch * (1 - v / 100);
    ctx.strokeStyle = "#263b51"; ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(w - right, y); ctx.stroke();
    ctx.fillStyle = "#91a5bd"; ctx.fillText(String(v), left - 8, y);
  }
  [{v:60,c:"#ffbe55"},{v:80,c:"#ff687d"}].forEach(t => {
    const y = top + ch * (1 - t.v / 100);
    ctx.save(); ctx.setLineDash([5,5]); ctx.strokeStyle = t.c; ctx.beginPath(); ctx.moveTo(left,y); ctx.lineTo(w-right,y); ctx.stroke(); ctx.restore();
  });
  if (!data.length) return;
  const x = i => left + (data.length === 1 ? cw / 2 : i / (data.length - 1) * cw);
  const y = v => top + ch * (1 - v / 100);
  const fill = ctx.createLinearGradient(0, top, 0, h-bottom);
  fill.addColorStop(0, "rgba(57,213,223,.22)"); fill.addColorStop(1, "rgba(57,213,223,.01)");
  ctx.beginPath(); data.forEach((r,i) => i ? ctx.lineTo(x(i),y(r.level)) : ctx.moveTo(x(i),y(r.level)));
  ctx.lineTo(x(data.length-1),h-bottom); ctx.lineTo(x(0),h-bottom); ctx.closePath(); ctx.fillStyle = fill; ctx.fill();
  ctx.beginPath(); data.forEach((r,i) => i ? ctx.lineTo(x(i),y(r.level)) : ctx.moveTo(x(i),y(r.level)));
  ctx.strokeStyle = "#39d5df"; ctx.lineWidth = 2.5; ctx.stroke();
  const last = data[data.length-1];
  ctx.beginPath(); ctx.arc(x(data.length-1),y(last.level),4,0,Math.PI*2); ctx.fillStyle="#fff"; ctx.fill();
  ctx.fillStyle="#91a5bd"; ctx.textAlign="center"; ctx.textBaseline="top";
  const indexes = [...new Set([0, Math.floor((data.length-1)/2), data.length-1])];
  indexes.forEach(i => ctx.fillText(data[i].time, x(i), h-bottom+8));
}

function updateStationInfo() {
  const s = stations[stationId()];
  $("stationName").textContent = s.name;
  $("stationDescription").textContent = s.description;
}

function eventMessage(status, r) {
  if (status === "danger") return "Critical simulated water level";
  if (status === "warning" && r.turbidity >= 50) return "Simulated turbidity warning";
  if (status === "warning") return "Simulated water-level risk warning";
  return "Conditions within configured demo limits";
}

function makeEvent(r, a) {
  return {
    station_id: r.station_id,
    station_name: r.station_name,
    recorded_at: r.recorded_at,
    event: eventMessage(a.status, r),
    level: r.level,
    rainfall: r.rainfall,
    flow_rate: r.flow_rate,
    turbidity: r.turbidity,
    risk_score: a.score,
    status: a.status,
    source: "simulated"
  };
}

function updateLatestEvent(event) {
  const root = $("latestEvent"); root.replaceChildren();
  const icon = document.createElement("span"); icon.className = "event-icon"; icon.textContent = event.status === "normal" ? "✓" : "!";
  const content = document.createElement("div");
  const title = document.createElement("strong"); title.textContent = event.event;
  const p = document.createElement("p");
  const time = event.recorded_at ? new Date(event.recorded_at).toLocaleTimeString() : (event.time || "");
  p.textContent = `${time} · ${event.station_name} · Level ${event.level}% · Risk ${event.risk_score}/100`;
  content.append(title,p); root.append(icon,content);
}

function normalizeCloudEvent(row) {
  return {
    ...row,
    stationName: row.station_name,
    score: row.risk_score,
    time: row.recorded_at ? new Date(row.recorded_at).toLocaleTimeString() : "",
    event: row.event || "Reading saved",
    source: row.source || "simulated"
  };
}

function renderHistory() {
  const tbody = $("alertRows"); tbody.replaceChildren();
  const rows = state.history[stationId()] || [];
  if (!rows.length) {
    const tr = document.createElement("tr"), td = document.createElement("td");
    td.colSpan = 7; td.className = "empty-cell"; td.textContent = "No records for this station yet.";
    tr.append(td); tbody.append(tr); return;
  }
  rows.slice(0,100).forEach(e => {
    const tr = document.createElement("tr");
    const time = e.time || (e.recorded_at ? new Date(e.recorded_at).toLocaleTimeString() : "");
    [time, e.station_name || e.stationName || "", e.event || "Reading", `${e.level}%`, `${e.risk_score ?? e.score}/100`].forEach(value => {
      const td = document.createElement("td"); td.textContent = String(value); tr.append(td);
    });
    const statusTd = document.createElement("td"), badge = document.createElement("span");
    badge.className = "table-status " + e.status; badge.textContent = String(e.status).toUpperCase(); statusTd.append(badge); tr.append(statusTd);
    const sourceTd = document.createElement("td"); sourceTd.textContent = e.source || "simulated"; tr.append(sourceTd);
    tbody.append(tr);
  });
}

function setCloudStatus(status, message) {
  $("cloudState").textContent = status;
  $("cloudState").className = "status-pill " + (status === "CONNECTED" ? "normal" : status === "ERROR" ? "danger" : "warning");
  $("cloudBadge").textContent = "Cloud: " + status.toLowerCase();
  $("cloudHealth").textContent = status === "CONNECTED" ? "● Connected" : status === "ERROR" ? "Connection error" : "Not configured";
  $("cloudHealth").className = status === "CONNECTED" ? "good" : "neutral";
  $("cloudMessage").textContent = message;
}

async function connectCloud() {
  const url = $("supabaseUrl").value.trim();
  const key = $("supabaseKey").value.trim();
  if (!url || !key) {
    setCloudStatus("NOT CONFIGURED", "Enter the Supabase project URL and public anon/publishable key.");
    return;
  }
  if (!window.supabase || !window.supabase.createClient) {
    setCloudStatus("ERROR", "Supabase client library did not load. Check your internet connection and reload.");
    return;
  }
  try {
    const client = window.supabase.createClient(url, key);
    // Test read permission and table availability.
    const { error } = await client.from("jal_readings").select("id").limit(1);
    if (error) throw error;
    state.supabase = client;
    state.cloudReady = true;
    // Save only on this device; never put secrets in the source code.
    try {
      sessionStorage.setItem(STORAGE_KEYS.url, url);
      sessionStorage.setItem(STORAGE_KEYS.key, key);
    } catch (_) {}
    setCloudStatus("CONNECTED", "Cloud connected. Loading saved demo history for this station.");
    await loadCloudHistory(stationId());
  } catch (err) {
    state.supabase = null; state.cloudReady = false;
    setCloudStatus("ERROR", "Connection failed: " + (err.message || "Check the project URL, key, table and RLS policies."));
  }
}

async function loadCloudHistory(id) {
  if (!state.cloudReady || !state.supabase) return;
  try {
    const { data, error } = await state.supabase
      .from("jal_readings")
      .select("*")
      .eq("station_id", id)
      .order("recorded_at", { ascending: false })
      .limit(100);
    if (error) throw error;
    const cloudRows = (data || []).map(row => {
      const e = normalizeCloudEvent(row);
      e.event = eventMessage(e.status, { turbidity: e.turbidity });
      return e;
    });
    // Keep recent cloud records visible; local events are retained if not already represented.
    const local = state.history[id] || [];
    const seen = new Set(cloudRows.map(e => e.id).filter(Boolean));
    state.history[id] = [...cloudRows, ...local.filter(e => !e.id || !seen.has(e.id))].slice(0,100);
    renderHistory();
    if (state.history[id][0]) updateLatestEvent(state.history[id][0]);
    setCloudStatus("CONNECTED", `Loaded ${cloudRows.length} saved cloud records for ${stations[id].name}.`);
  } catch (err) {
    setCloudStatus("ERROR", "Could not load cloud history: " + (err.message || "Check RLS policies."));
  }
}

async function saveCloudReading(r, a) {
  if (!state.cloudReady || !state.supabase || state.saving) return;
  state.saving = true;
  try {
    const row = {
      station_id: r.station_id,
      station_name: r.station_name,
      source: "simulated",
      level: r.level,
      rainfall: r.rainfall,
      flow_rate: r.flow_rate,
      turbidity: r.turbidity,
      risk_score: a.score,
      status: a.status,
      event: eventMessage(a.status, r),
      recorded_at: r.recorded_at
    };
    const { error } = await state.supabase.from("jal_readings").insert(row);
    if (error) throw error;
    setCloudStatus("CONNECTED", "Demo reading saved to cloud at " + getTime() + ".");
  } catch (err) {
    setCloudStatus("ERROR", "Cloud save failed: " + (err.message || "Check insert policy and table schema."));
  } finally {
    state.saving = false;
  }
}

function runAssessment(saveToCloud = true) {
  const r = generateReading();
  const a = assessRisk(r);
  const id = r.station_id;
  state.readings[id].push({ ...r, time: getTime() });
  state.readings[id] = state.readings[id].slice(-24);
  updateStationInfo(); updateMeters(r); updateRisk(a); drawChart();

  const event = makeEvent(r, a);
  event.time = getTime();
  const history = state.history[id];
  const last = history[0];
  const isNewState = !last || last.status !== event.status || last.event !== event.event;
  // Log every manual test; automatic polling logs only when the status/event changes.
  const manual = saveToCloud === "manual";
  const shouldLog = manual || isNewState;
  if (shouldLog) {
    history.unshift(event);
    state.history[id] = history.slice(0,100);
    updateLatestEvent(event); renderHistory();
    if (saveToCloud !== false) saveCloudReading(r, a);
  } else if (!last) {
    updateLatestEvent(event);
  }
}

function exportCSV() {
  const rows = state.history[stationId()] || [];
  if (!rows.length) { alert("No history to export. Generate a reading first."); return; }
  const keys = ["recorded_at","station_id","station_name","event","level","rainfall","flow_rate","turbidity","risk_score","status","source"];
  const escape = value => '"' + String(value ?? "").replace(/"/g,'""') + '"';
  const csv = [keys.join(","), ...rows.map(row => keys.map(key => escape(row[key] ?? row[({station_name:"stationName",risk_score:"score"})[key]] )).join(","))].join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = stationId() + "-jal-rakshak-history.csv";
  document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

$("scenario").addEventListener("change", () => runAssessment("manual"));
$("refreshBtn").addEventListener("click", () => runAssessment("manual"));
$("station").addEventListener("change", async () => {
  updateStationInfo(); renderHistory(); drawChart();
  if (state.cloudReady) await loadCloudHistory(stationId());
  runAssessment("manual");
});
$("exportBtn").addEventListener("click", exportCSV);
$("clearBtn").addEventListener("click", () => {
  state.history[stationId()] = [];
  renderHistory();
  setCloudStatus(state.cloudReady ? "CONNECTED" : "NOT CONFIGURED",
    "Local history cleared for this station. Cloud records were not deleted.");
});
$("connectCloudBtn").addEventListener("click", connectCloud);
$("disconnectCloudBtn").addEventListener("click", () => {
  state.supabase = null; state.cloudReady = false;
  setCloudStatus("NOT CONFIGURED", "Disconnected. The dashboard continues using simulated readings locally.");
});
window.addEventListener("resize", drawChart);

async function initialize() {
  updateClock(); setInterval(updateClock, 1000);
  updateStationInfo(); renderHistory();
  runAssessment(false);
  setInterval(() => runAssessment(true), 5000);

  // Credentials are only remembered for this browser session, not embedded in the GitHub files.
  try {
    const url = sessionStorage.getItem(STORAGE_KEYS.url);
    const key = sessionStorage.getItem(STORAGE_KEYS.key);
    if (url && key) {
      $("supabaseUrl").value = url;
      $("supabaseKey").value = key;
      await connectCloud();
    } else {
      setCloudStatus("NOT CONFIGURED", "Cloud is optional. Simulation-only mode is active.");
    }
  } catch (_) {
    setCloudStatus("NOT CONFIGURED", "Cloud is optional. Simulation-only mode is active.");
  }
}
initialize();
