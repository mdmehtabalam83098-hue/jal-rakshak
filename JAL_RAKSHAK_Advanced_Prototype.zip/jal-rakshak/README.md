# JAL RAKSHAK — Advanced GitHub Pages prototype

This is an educational water-monitoring dashboard with simulated sensor values, station selection, rule-based risk scoring, a water-level chart, CSV export, and optional Supabase cloud history.

## Files
- `index.html` — dashboard markup
- `style.css` — responsive dashboard styling
- `script.js` — simulation, risk rules, chart, CSV, and Supabase connection
- `supabase-schema.sql` — database table and Row Level Security policies

## Publish on GitHub Pages
1. Upload the three website files to the repository root.
2. In repository Settings > Pages, select Deploy from a branch, `main`, `/(root)`.
3. Wait for deployment, then hard-refresh the site.

## Optional cloud history with Supabase
1. Create a Supabase project.
2. Open SQL Editor and run all of `supabase-schema.sql`.
3. In Project Settings / API, copy the Project URL and public anon/publishable key.
4. Open the website's Cloud database connection panel and enter those two values.
5. Click Connect cloud.

Never use a Supabase `service_role` or secret key in frontend code. The SQL policies intentionally permit public read/insert for this non-sensitive demonstration; anonymous users can add demo records. Do not use this setup for private, safety-critical, or production data. Add authentication, stricter access controls, rate limiting, and server-side validation before wider deployment.

## Data and safety
- All readings produced by this website are simulated.
- No physical sensor is connected.
- Risk score is a demonstration rule, not a validated flood prediction.
- Cloud history is optional. This starter uses direct browser inserts for demo data.
- Clearing local history does not delete cloud rows.
- The browser key is stored in `sessionStorage` only for the current tab session.

## Future physical sensor integration
Use a trusted backend/API to receive authenticated, validated measurements from a microcontroller. Do not let a device or public browser write unrestricted trusted sensor readings directly to the database.
